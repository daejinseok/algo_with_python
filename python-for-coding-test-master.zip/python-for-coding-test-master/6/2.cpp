#include <bits/stdc++.h>

using namespace std;

int arr[2] = {3, 5};

int main(void) {
    swap(arr[0], arr[1]);
    cout << arr[0] << ' ' << arr[1] << '\n';
}
