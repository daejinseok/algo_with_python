array = [7, 5, 9, 0, 3, 1, 6, 2, 4, 8]

array.sort()
print(array)
